function difference = tensorfronorm(A, B)

	
	difference = norm(vec(A-B), "fro");
end
